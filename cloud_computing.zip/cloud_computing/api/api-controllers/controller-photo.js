const db = require('../db');

// Upload Photo
const uploadPhoto = async(req, res) => {
    const { user_id, title } = req.body;
    const photo_url = `/photo-uploaded/${req.file.filename}`; // URL file foto yang diunggah

    try {
        const [result] = await db.query(
            `INSERT INTO photos (user_id. title, photo_url, uploaded_at) VALUES (?, ?, ?, NOW())`,
            [user_id, title, photo_url]
        );
        console.log(req.body);
        res.status(201).json({ id: result.insertId, title, photo_url });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
};


// Get photos by user
const getPhotosByUser = async (req, res) => {
    const { user_id } = req.params;

    try {
        const [photos] = await db.query(
            `SELECT id, title, photo_url, uploaded_at FROM photos WHERE user_id = ?`,
            [user_id]
        );
        console.log(photos);
        req.status(200).json(photos);
    } catch (error) {
        console.error(error);
        req.status(500).json({ error: error.message });
    }
};

module.exports = { uploadPhoto, getPhotosByUser };