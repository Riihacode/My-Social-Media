const db = require('../db');

// Register user 
const registerUser = async (registerUser, res) => {
    const { username, email, password } = req.body;

    try {
        const [result] = await db.query (
            `INSERT INTO users (username, email, password) VALUES (?, ?, ?)`,
            [username, email, password]
        );
        res.status(201).json({ id: result.insertId, username, email });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}


// Login User
const loginUser =  async (req, res) => {
    const { email, password } = req.body;

    try {
         // Cari pengguna berdasarkan email dan password
         const [user] = await db.query(
            `SELECT id, username, email FROM users WHERE email =? AND password =?`,
            [email, password]
         );

         if(user.length === 0){
            // Jika pengguna tidak ditemukan 
            return res.status(401).json({ error: "Invalid email or password" });
         }

         // Login berhasil
         console.log(user[0]);  // Log pengguna yang berhasil login
         res.status(200).json({ message: "Login successful", user: user[0] });
    } catch (error) {
        console.error(error); 
        res.status(500).json({ error: error.message});
    }
};

module.exports = { registerUser, loginUser };