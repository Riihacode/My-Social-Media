const db = require('../db');

// Upload Video
const uploadVideo = async (req, res) => {
    const { user_id, title, description, video_url} = req.body;

    try {
        const [result] = await db.query(
            `INSERT INTO videos (user_id, title, description, video_url, uploaded_at) VALUES (?, ?, ?, ?, NOW())`,
            [user_id, title, description, video_url]
        );
        console.log(req.body);
        res.status(201).json({ id: result.insertId, title, description, video_url });
    } catch (error) {
        console.log(result);
        res.status(500).json({ error: error.message })
    }
};


// Get all video
const getAllVideos = async (req, res) =>{
    try {
        const [videos] = await db.query(
            `SELECT v.id, v.description, v.video_url, v.uploaded_at, u.username
            FROM videos v
            JOIN users u ON v.user_id = u.id`
        );
        console.log(videos);
        res.status(200).json(videos);
    } catch (error) {
        console.error(error);   // Log hasil query
        res.status(500).json({ error: error.message });
    }
};


// Get video by user
const getVideosByUser = async (req, res) => {
    const { user_id } = req.params;

    try {
        const [videos] = await db.query(
            `SELECT id, title, description, video_url, uploaded_at FROM videos WHERE user_id = ?`,
            [user_id]
        );
        console.log(videos);    // Log hasil query
        res.status(201).json(videos);
    } catch (error) {
        console.error(error);   // Log error
        res.status(500).json({ error: error.message })
    }
};

module.exports = { uploadVideo, getAllVideos, getVideosByUser };