const express = require('express');
const { uploadVideo, getAllVideos, getVideosByUser } = require('../api-controllers/controller-video');
const upload = require('../api-middleware/middleware-video');   // Import konfigurasi multer
const router = express.Router();

// Endpoint untuk video
router.post('/upload', upload.single('video'), uploadVideo);
router.get('/', getAllVideos);
router.get('/:user_id', getVideosByUser);

module.exports = router;