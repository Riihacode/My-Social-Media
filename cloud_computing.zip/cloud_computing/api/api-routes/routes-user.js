const express = require('express');
const { registerUser, loginUser } = require('../api-controllers/controller-user');
const router = express.Router();

// Endpoint register dan login
router.post('/register', registerUser);
router.post('/login', loginUser);

module.exports = router;
