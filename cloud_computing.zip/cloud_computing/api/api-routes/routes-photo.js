const express = require('express');
const {uploadPhoto, getPhotosByUser } = require('../api-controllers/controller-photo');
const upload = require('../api-middleware/middleware-photo');
const router = express.Router();

// Endpoint untuk upload photo (dengan file fisik)
router.post('/upload', upload.single('photo'), uploadPhoto);

// Endpoint untuk mendapatkan semua photo oleh user tertentu
router.get('/:user_id', getPhotosByUser);

module.exports = router;